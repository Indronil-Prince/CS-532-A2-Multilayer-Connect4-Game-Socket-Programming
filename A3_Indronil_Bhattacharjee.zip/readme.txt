#To setup server

npm install express
npm install http
npm install socket.io

-----------------------------

#To start server

node app.js

-----------------------------

#In the browser, go to

localhost:3000/connect4.html

-----------------------------